console.log('====================================');
console.log("INDEX.JS RUNNING...");
console.log('====================================');

// change 'SCSS' color 
var color = document.getElementById('color');
var span = document.getElementById('scss');
var globe = document.getElementById('globe');
color.addEventListener('change',(e)=>{
    span.style.color = e.target.value;
    globe.style.color = e.target.value;
})